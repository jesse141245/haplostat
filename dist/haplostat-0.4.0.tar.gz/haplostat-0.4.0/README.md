## Installation

```bash
pip install haplo-package